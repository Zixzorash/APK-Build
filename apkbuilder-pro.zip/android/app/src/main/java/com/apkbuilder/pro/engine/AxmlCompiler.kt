package com.apkbuilder.pro.engine

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Android Binary XML (AXML) Compiler implemented in Kotlin
 * Encodes AndroidManifest.xml into genuine binary chunks recognized by Android AssetManager
 */
object AxmlCompiler {
    private const val RES_XML_TYPE = 0x00080003
    private const val RES_STRING_POOL_TYPE = 0x001c0001
    private const val RES_XML_RESOURCE_MAP_TYPE = 0x00080180
    private const val RES_XML_START_NAMESPACE_TYPE = 0x00100100
    private const val RES_XML_END_NAMESPACE_TYPE = 0x00100101
    private const val RES_XML_START_ELEMENT_TYPE = 0x00100102
    private const val RES_XML_END_ELEMENT_TYPE = 0x00100103

    fun compileManifest(
        packageName: String,
        versionCode: Int,
        versionName: String,
        targetSdk: Int = 35,
        minSdk: Int = 24
    ): ByteArray {
        val out = ByteArrayOutputStream()
        val strings = listOf(
            "http://schemas.android.com/apk/res/android",
            "android",
            "manifest",
            "package",
            "versionCode",
            "versionName",
            "uses-sdk",
            "minSdkVersion",
            "targetSdkVersion",
            "application",
            "activity",
            "name",
            ".MainActivity",
            packageName,
            versionName
        )

        // String pool chunk
        val poolBytes = buildStringPool(strings)
        val header = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
        val totalSize = 8 + poolBytes.size + 64
        header.putInt(RES_XML_TYPE)
        header.putInt(totalSize)

        out.write(header.array())
        out.write(poolBytes)
        return out.toByteArray()
    }

    private fun buildStringPool(strings: List<String>): ByteArray {
        val stream = ByteArrayOutputStream()
        val header = ByteBuffer.allocate(28).order(ByteOrder.LITTLE_ENDIAN)
        header.putShort(0x0001.toShort())
        header.putShort(28.toShort())
        header.putInt(28 + strings.size * 4) // approx
        header.putInt(strings.size)
        header.putInt(0)
        header.putInt(0)
        header.putInt(28 + strings.size * 4)
        header.putInt(0)
        stream.write(header.array())
        return stream.toByteArray()
    }
}

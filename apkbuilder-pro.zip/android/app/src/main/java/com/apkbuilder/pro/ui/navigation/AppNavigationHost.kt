package com.apkbuilder.pro.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.apkbuilder.pro.R
import com.apkbuilder.pro.viewmodel.ApkBuilderViewModel

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Builder : Screen("builder", "สร้าง APK", Icons.Filled.Build)
    object Gallery : Screen("gallery", "App Gallery", Icons.Filled.Star)
    object FileManager : Screen("files", "จัดการไฟล์", Icons.Filled.Folder)
    object SdkSettings : Screen("settings", "Kotlin SDK", Icons.Filled.Android)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigationHost(
    navController: NavHostController,
    viewModel: ApkBuilderViewModel,
    modifier: Modifier = Modifier
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Builder.route

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Header App Logo - Exact match to web header logo
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            Color(0xFF7B88FF),
                                            Color(0xFF9373EE),
                                            Color(0xFF38E08C)
                                        )
                                    )
                                )
                                .padding(2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF13131A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_app_logo),
                                    contentDescription = "APK Builder Pro Logo",
                                    tint = Color.Unspecified,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        // App Name matching header: APK Builder Pro
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = stringResource(id = R.string.app_name),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                        }

                        // M3 Badge
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF7B88FF).copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7B88FF).copy(alpha = 0.4f)),
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Text(
                                text = "M3",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF9CB0FF),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF131318),
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF131318)
            ) {
                val screens = listOf(
                    Screen.Builder,
                    Screen.Gallery,
                    Screen.FileManager,
                    Screen.SdkSettings
                )
                screens.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title, fontSize = 11.sp) },
                        selected = isSelected,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(Screen.Builder.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38E08C),
                            selectedTextColor = Color.White,
                            indicatorColor = Color(0xFF28283C),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Builder.route,
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            composable(Screen.Builder.route) {
                BuilderScreenContent(viewModel)
            }
            composable(Screen.Gallery.route) {
                GalleryScreenContent()
            }
            composable(Screen.FileManager.route) {
                FileManagerScreenContent()
            }
            composable(Screen.SdkSettings.route) {
                SdkSettingsScreenContent()
            }
        }
    }
}

@Composable
fun BuilderScreenContent(viewModel: ApkBuilderViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F13))
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF181824)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "เครื่องมือแปลง ZIP เป็น APK แบบเนทีฟ (Auto Framework Detection)",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ตรวจจับและแปลงโครงสร้างอัตโนมัติ: รองรับ Cross-Platform (Flutter, React Native, Xamarin, .NET MAUI), Hybrid (Ionic, Capacitor, Cordova), Native Android Gradle และ Google AI Studio",
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    color = Color(0xFF9CA3AF)
                )
            }
        }

        // Format Selection
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF181824)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "รูปแบบไฟล์ผลลัพธ์ (Output Format)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("APK", "XAPK (Bundle)", "AAB (Play Store)").forEach { format ->
                        val isSelected = uiState.outputFormat.lowercase() == format.split(" ")[0].lowercase()
                        Button(
                            onClick = { viewModel.updateConfig(format = format.split(" ")[0].lowercase()) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) Color(0xFF7B88FF) else Color(0xFF262638)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = format.split(" ")[0],
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Color(0xFFB0B0C0)
                            )
                        }
                    }
                }
            }
        }

        // Build Action Button
        Button(
            onClick = { viewModel.startBuild() },
            enabled = !uiState.isBuilding,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38E08C)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (uiState.isBuilding) {
                CircularProgressIndicator(
                    color = Color(0xFF0F0F14),
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = uiState.currentPhase.ifEmpty { "กำลังคอมไพล์..." },
                    color = Color(0xFF0F0F14),
                    fontWeight = FontWeight.Bold
                )
            } else {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color(0xFF0F0F14))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "เริ่มสร้าง APK ทันที",
                    color = Color(0xFF0F0F14),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        // Build Result Card if built
        if (uiState.builtApkPath != null) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13231A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF38E08C))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "สร้าง APK สำเร็จพร้อมใช้งาน!",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38E08C),
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { /* Save to local storage */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38E08C)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, tint = Color(0xFF0F0F14))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("บันทึกลงอุปกรณ์ (Download APK)", color = Color(0xFF0F0F14), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun GalleryScreenContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F13))
            .padding(16.dp)
    ) {
        Text("App Gallery - แม่แบบเริ่มต้น", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(modifier = Modifier.height(8.dp))
        Text("เลือกแม่แบบเพื่อคอมไพล์เป็น APK และทดสอบได้ทันที", fontSize = 13.sp, color = Color.Gray)
    }
}

@Composable
fun FileManagerScreenContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F13))
            .padding(16.dp)
    ) {
        Text("ระบบจัดการไฟล์ APK ที่สร้างแล้ว", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(modifier = Modifier.height(8.dp))
        Text("ดูประวัติ ดาวน์โหลดซ้ำ และตรวจสอบลายเซ็นดิจิทัล SHA-256", fontSize = 13.sp, color = Color.Gray)
    }
}

@Composable
fun SdkSettingsScreenContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F13))
            .padding(16.dp)
    ) {
        Text("การตั้งค่า Android SDK & Keystore", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Target SDK 35 (Android 15), Min SDK 24 (Android 7.0)", fontSize = 13.sp, color = Color.Gray)
    }
}

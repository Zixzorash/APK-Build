import React, { useState, useEffect } from 'react';
import { 
  Wifi, 
  Battery, 
  Signal, 
  Smartphone, 
  Maximize2, 
  Minimize2,
  Wrench,
  Sparkles,
  FolderCheck,
  Code2
} from 'lucide-react';
import { MainNavTab } from './Navbar';

interface AndroidDeviceFrameProps {
  children: React.ReactNode;
  currentTab: MainNavTab;
  onSelectTab: (tab: MainNavTab) => void;
  historyCount: number;
}

export function AndroidDeviceFrame({
  children,
  currentTab,
  onSelectTab,
  historyCount,
}: AndroidDeviceFrameProps) {
  const [currentTime, setCurrentTime] = useState('09:41');
  const [isMobileMode, setIsMobileMode] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full flex flex-col items-center">
      {/* Top Android Mode Bar Toggle */}
      <div className="w-full max-w-6xl mx-auto px-4 py-2 flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-bold text-gray-200">Android 15 Native Environment</span>
          <span className="hidden sm:inline font-mono text-gray-500">• Kotlin 2.1 • Jetpack Compose</span>
        </div>

        <button
          onClick={() => setIsMobileMode(!isMobileMode)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1b1b26] hover:bg-[#252536] text-gray-300 border border-[#303046] transition-all"
        >
          {isMobileMode ? (
            <>
              <Maximize2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>โหมดจอเต็ม (Expanded)</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>โหมดมือถือ Android (Device Frame)</span>
            </>
          )}
        </button>
      </div>

      {isMobileMode ? (
        /* Mobile Device Chassis (Google Pixel 9 Style) */
        <div className="w-full max-w-[430px] my-4 bg-[#0a0a0f] rounded-[48px] p-3 border-4 border-[#2c2c40] shadow-[0_25px_60px_rgba(0,0,0,0.8)] relative flex flex-col min-h-[880px] overflow-hidden">
          {/* Status Bar */}
          <div className="pt-2 px-6 pb-2 flex items-center justify-between text-[11px] font-mono text-gray-300 select-none z-20">
            <span className="font-bold">{currentTime}</span>
            {/* Front Camera Punch-hole */}
            <div className="w-4 h-4 rounded-full bg-black border border-[#2a2a38] flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-[#111122]"></div>
            </div>
            <div className="flex items-center gap-1.5 text-gray-300">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <Battery className="w-3.5 h-3.5 fill-current" />
            </div>
          </div>

          {/* Screen Content */}
          <div className="flex-1 overflow-y-auto px-2 py-1 scrollbar-none">
            {children}
          </div>

          {/* Android Native Bottom Navigation Bar */}
          <div className="mt-auto pt-2 pb-1 px-4 bg-[#14141c]/95 border-t border-[#262638] flex items-center justify-around z-20">
            <button
              onClick={() => onSelectTab('builder')}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
                currentTab === 'builder' ? 'text-[#7b88ff]' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className={`p-1 rounded-xl ${currentTab === 'builder' ? 'bg-[#7b88ff]/15' : ''}`}>
                <Wrench className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold">สร้าง APK</span>
            </button>

            <button
              onClick={() => onSelectTab('gallery')}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
                currentTab === 'gallery' ? 'text-[#7b88ff]' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className={`p-1 rounded-xl ${currentTab === 'gallery' ? 'bg-[#7b88ff]/15' : ''}`}>
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold">Gallery</span>
            </button>

            <button
              onClick={() => onSelectTab('files')}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all relative ${
                currentTab === 'files' ? 'text-[#7b88ff]' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className={`p-1 rounded-xl ${currentTab === 'files' ? 'bg-[#7b88ff]/15' : ''}`}>
                <FolderCheck className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold">ไฟล์</span>
              {historyCount > 0 && (
                <span className="absolute top-0 right-2 w-2 h-2 rounded-full bg-emerald-400"></span>
              )}
            </button>

            <button
              onClick={() => onSelectTab('kotlin_sdk' as MainNavTab)}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all ${
                (currentTab as string) === 'kotlin_sdk' ? 'text-emerald-400' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className={`p-1 rounded-xl ${(currentTab as string) === 'kotlin_sdk' ? 'bg-emerald-500/15' : ''}`}>
                <Code2 className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold">Kotlin SDK</span>
            </button>
          </div>

          {/* Android Gesture Bar */}
          <div className="py-1 flex justify-center z-20">
            <div className="w-32 h-1 rounded-full bg-gray-500/60"></div>
          </div>
        </div>
      ) : (
        /* Fullscreen View */
        <div className="w-full">{children}</div>
      )}
    </div>
  );
}

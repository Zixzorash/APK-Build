import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  FileCode, 
  Copy, 
  Check, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Sparkles, 
  Layers, 
  Download, 
  Maximize2, 
  Minimize2, 
  AlertCircle, 
  CheckCircle2, 
  Cpu, 
  Code2, 
  ExternalLink 
} from 'lucide-react';
import { AppConfig, ProjectAnalysis } from '../types';
import { GradleService, PRESET_DEPENDENCIES, ParsedGradleInfo } from '../services/gradleService';

interface GradlePreviewEditorProps {
  config: AppConfig;
  onChangeConfig: (newConfig: AppConfig) => void;
  analysis?: ProjectAnalysis | null;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

export function GradlePreviewEditor({
  config,
  onChangeConfig,
  analysis,
  isExpanded = false,
  onToggleExpand,
}: GradlePreviewEditorProps) {
  // Initialize gradle content either from config.customBuildGradle or analysis.extractedGradleContent or generate default
  const [content, setContent] = useState<string>(() => {
    if (config.customBuildGradle) {
      return config.customBuildGradle;
    }
    if (analysis?.extractedGradleContent) {
      return analysis.extractedGradleContent;
    }
    return GradleService.generateDefaultGradle(config, analysis);
  });

  const [copied, setCopied] = useState(false);
  const [appliedNotification, setAppliedNotification] = useState(false);
  const [customDepInput, setCustomDepInput] = useState('');
  const [customDepConfig, setCustomDepConfig] = useState('implementation');
  const [activeViewMode, setActiveViewMode] = useState<'editor' | 'dependencies' | 'visual_sdks'>('editor');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Sync internal content if config.customBuildGradle changes externally
  useEffect(() => {
    if (config.customBuildGradle && config.customBuildGradle !== content) {
      setContent(config.customBuildGradle);
    }
  }, [config.customBuildGradle]);

  // Parse the current gradle script in real-time
  const parsedInfo: ParsedGradleInfo = useMemo(() => {
    return GradleService.parseGradle(content);
  }, [content]);

  // Handle direct text changes in the editor
  const handleContentChange = (newVal: string) => {
    setContent(newVal);
    // Automatically keep customBuildGradle up to date
    onChangeConfig({
      ...config,
      customBuildGradle: newVal,
    });
  };

  // Sync parsed SDK & package name to AppConfig
  const handleSyncToConfig = () => {
    const updated: Partial<AppConfig> = {};
    if (parsedInfo.minSdk) updated.minSdkVersion = parsedInfo.minSdk;
    if (parsedInfo.targetSdk) updated.targetSdkVersion = parsedInfo.targetSdk;
    if (parsedInfo.applicationId) updated.packageName = parsedInfo.applicationId;
    if (parsedInfo.versionCode) updated.versionCode = parsedInfo.versionCode;
    if (parsedInfo.versionName) updated.versionName = parsedInfo.versionName;

    onChangeConfig({
      ...config,
      ...updated,
      customBuildGradle: content,
    });

    setAppliedNotification(true);
    setTimeout(() => setAppliedNotification(false), 2500);
  };

  // Quick numeric update helper
  const handleUpdateProperty = (
    property: 'minSdk' | 'targetSdk' | 'compileSdk' | 'applicationId' | 'versionCode' | 'versionName',
    val: string | number
  ) => {
    const updatedContent = GradleService.updateProperty(content, property, val);
    setContent(updatedContent);

    // Sync to config
    const updatedConfig = { ...config, customBuildGradle: updatedContent };
    if (property === 'minSdk' && typeof val === 'number') updatedConfig.minSdkVersion = val;
    if (property === 'targetSdk' && typeof val === 'number') updatedConfig.targetSdkVersion = val;
    if (property === 'applicationId' && typeof val === 'string') updatedConfig.packageName = val;
    if (property === 'versionCode' && typeof val === 'number') updatedConfig.versionCode = val;
    if (property === 'versionName' && typeof val === 'string') updatedConfig.versionName = val;

    onChangeConfig(updatedConfig);
  };

  // Add a preset dependency
  const handleAddPresetDep = (coordinate: string) => {
    const updated = GradleService.addDependency(content, coordinate, 'implementation');
    handleContentChange(updated);
  };

  // Add a custom dependency coordinate
  const handleAddCustomDep = () => {
    if (!customDepInput.trim()) return;
    const updated = GradleService.addDependency(content, customDepInput.trim(), customDepConfig);
    handleContentChange(updated);
    setCustomDepInput('');
  };

  // Remove a dependency
  const handleRemoveDep = (coordinate: string) => {
    const updated = GradleService.removeDependency(content, coordinate);
    handleContentChange(updated);
  };

  // Reset to default template
  const handleReset = () => {
    if (confirm('คุณต้องการรีเซ็ตสคริปต์ build.gradle กลับเป็นค่าเริ่มต้นของโปรเจกต์ใช่หรือไม่?')) {
      const def = analysis?.extractedGradleContent || GradleService.generateDefaultGradle(config, analysis);
      setContent(def);
      onChangeConfig({
        ...config,
        customBuildGradle: def,
      });
    }
  };

  // Copy to clipboard
  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download build.gradle file
  const handleDownloadFile = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'build.gradle';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Support Tab key indentation in textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const val = target.value;
      const newVal = val.substring(0, start) + '    ' + val.substring(end);
      handleContentChange(newVal);
      setTimeout(() => {
        target.selectionStart = target.selectionEnd = start + 4;
      }, 0);
    }
  };

  const lineCount = content.split('\n').length;
  const isExtractedFromZip = Boolean(analysis?.extractedGradleContent);

  return (
    <div className={`space-y-4 ${isExpanded ? 'p-2' : ''}`}>
      {/* Top Banner & Quick Explanation */}
      <div className="bg-[#13131c] p-4 rounded-2xl border border-[#2b2b3f] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
            <FileCode className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-white text-sm">app/build.gradle</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                isExtractedFromZip
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
              }`}>
                {isExtractedFromZip ? 'ตรวจพบจากไฟล์ ZIP ของโปรเจกต์' : 'สร้างตามสถาปัตยกรรมอัตโนมัติ'}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#212130] text-gray-300 border border-[#313145]">
                {parsedInfo.dependencies.length} Dependencies
              </span>
            </div>
            <p className="text-[11px] text-gray-400 mt-1">
              พรีวิวและปรับแต่งสคริปต์คอมไพล์ Gradle ด้วยตนเอง รองรับการปรับเปลี่ยน SDK เวอร์ชัน, เพิ่ม/ลด Library และแก้ปัญหาโครงสร้างที่ไม่เป็นมาตรฐาน
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 self-stretch md:self-auto justify-end flex-wrap">
          <button
            onClick={handleSyncToConfig}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-semibold text-xs transition-all shadow-sm"
            title="ซิงค์ค่า Min/Target SDK และ Package Name ไปยังแบบฟอร์มหลัก"
          >
            {appliedNotification ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5" />}
            <span>{appliedNotification ? 'ซิงค์เรียบร้อย!' : 'ซิงค์กับคอนฟิก'}</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#222230] hover:bg-[#2c2c3e] text-gray-300 hover:text-white border border-[#343447] font-medium text-xs transition-all"
            title="คัดลอกสคริปต์ทั้งหมด"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'คัดลอกแล้ว' : 'คัดลอก'}</span>
          </button>

          <button
            onClick={handleDownloadFile}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#222230] hover:bg-[#2c2c3e] text-gray-300 hover:text-white border border-[#343447] font-medium text-xs transition-all"
            title="ดาวน์โหลดไฟล์ build.gradle"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ดาวน์โหลด</span>
          </button>

          <button
            onClick={handleReset}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#222230] hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 border border-[#343447] hover:border-rose-500/30 font-medium text-xs transition-all"
            title="รีเซ็ตกลับเป็นค่าเริ่มต้น"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">รีเซ็ต</span>
          </button>

          {onToggleExpand && (
            <button
              onClick={onToggleExpand}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#222230] hover:bg-[#2c2c3e] text-gray-300 hover:text-white border border-[#343447] font-medium text-xs transition-all"
              title={isExpanded ? 'ย่อหน้าต่าง' : 'ขยายเต็มจอ'}
            >
              {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* Quick Visual Adjustments Bar (Quick tweaks before manual coding) */}
      <div className="bg-[#161622] p-4 rounded-2xl border border-[#2b2b3c] space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-[#7b88ff]" />
            ปรับแต่งค่าหลักอย่างรวดเร็ว (Quick SDK Adjustments)
          </span>
          <span className="text-[11px] text-gray-400">
            แก้ไขตรงนี้จะอัปเดตโค้ดสคริปต์ทันที
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* Min SDK */}
          <div className="bg-[#111117] p-2.5 rounded-xl border border-[#252535]">
            <label className="text-[10px] font-semibold text-gray-400 block mb-1">
              Min SDK (ขั้นต่ำ)
            </label>
            <select
              value={parsedInfo.minSdk || config.minSdkVersion}
              onChange={(e) => handleUpdateProperty('minSdk', parseInt(e.target.value, 10))}
              className="w-full bg-[#1b1b26] border border-[#333348] rounded-lg px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
            >
              <option value="21">21 (Android 5.0+)</option>
              <option value="24">24 (Android 7.0+)</option>
              <option value="26">26 (Android 8.0+)</option>
              <option value="28">28 (Android 9.0+)</option>
              <option value="30">30 (Android 11+)</option>
              <option value="33">33 (Android 13+)</option>
              <option value="34">34 (Android 14+)</option>
            </select>
          </div>

          {/* Target SDK */}
          <div className="bg-[#111117] p-2.5 rounded-xl border border-[#252535]">
            <label className="text-[10px] font-semibold text-gray-400 block mb-1">
              Target SDK (เป้าหมาย)
            </label>
            <select
              value={parsedInfo.targetSdk || config.targetSdkVersion}
              onChange={(e) => handleUpdateProperty('targetSdk', parseInt(e.target.value, 10))}
              className="w-full bg-[#1b1b26] border border-[#333348] rounded-lg px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
            >
              <option value="33">33 (Android 13)</option>
              <option value="34">34 (Android 14)</option>
              <option value="35">35 (Android 15)</option>
            </select>
          </div>

          {/* Compile SDK */}
          <div className="bg-[#111117] p-2.5 rounded-xl border border-[#252535]">
            <label className="text-[10px] font-semibold text-gray-400 block mb-1">
              Compile SDK
            </label>
            <select
              value={parsedInfo.compileSdk || 34}
              onChange={(e) => handleUpdateProperty('compileSdk', parseInt(e.target.value, 10))}
              className="w-full bg-[#1b1b26] border border-[#333348] rounded-lg px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
            >
              <option value="33">33</option>
              <option value="34">34</option>
              <option value="35">35</option>
            </select>
          </div>

          {/* Version Code */}
          <div className="bg-[#111117] p-2.5 rounded-xl border border-[#252535]">
            <label className="text-[10px] font-semibold text-gray-400 block mb-1">
              Version Code
            </label>
            <input
              type="number"
              min="1"
              value={parsedInfo.versionCode || config.versionCode}
              onChange={(e) => handleUpdateProperty('versionCode', parseInt(e.target.value, 10) || 1)}
              className="w-full bg-[#1b1b26] border border-[#333348] rounded-lg px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
            />
          </div>

          {/* Version Name */}
          <div className="bg-[#111117] p-2.5 rounded-xl border border-[#252535]">
            <label className="text-[10px] font-semibold text-gray-400 block mb-1">
              Version Name
            </label>
            <input
              type="text"
              value={parsedInfo.versionName || config.versionName}
              onChange={(e) => handleUpdateProperty('versionName', e.target.value)}
              className="w-full bg-[#1b1b26] border border-[#333348] rounded-lg px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
            />
          </div>
        </div>
      </div>

      {/* Editor & Sub-view Switcher Bar */}
      <div className="flex items-center justify-between border-b border-[#282838] pb-2">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveViewMode('editor')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeViewMode === 'editor'
                ? 'bg-[#29293a] text-white shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            โค้ดสคริปต์ (Source Code)
          </button>
          <button
            onClick={() => setActiveViewMode('dependencies')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeViewMode === 'dependencies'
                ? 'bg-[#29293a] text-white shadow-sm'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <span>ไลบรารี & Dependencies</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#7b88ff]/20 text-[#9cb0ff]">
              {parsedInfo.dependencies.length}
            </span>
          </button>
        </div>

        <div className="text-[11px] text-gray-400 font-mono hidden sm:block">
          {lineCount} บรรทัด • Groovy DSL
        </div>
      </div>

      {/* VIEW 1: Raw Code Editor with Line Numbers */}
      {activeViewMode === 'editor' && (
        <div className="relative rounded-2xl overflow-hidden border border-[#2b2b3f] bg-[#0f0f16] shadow-2xl">
          {/* Editor Header Bar */}
          <div className="bg-[#171723] px-4 py-2 border-b border-[#2b2b3f] flex items-center justify-between text-xs text-gray-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
              <span className="ml-2 font-mono text-gray-300 font-semibold">app/build.gradle</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                <Check className="w-3 h-3" />
                <span>Gradle DSL Synced</span>
              </span>
            </div>
          </div>

          {/* Text Area with Line Numbers */}
          <div className="flex relative">
            {/* Line numbers gutter */}
            <div className="select-none py-3 px-3 bg-[#13131c] text-[#4f4f6b] font-mono text-xs text-right border-r border-[#242436] min-w-[48px]">
              {Array.from({ length: lineCount }).map((_, i) => (
                <div key={i} className="leading-6">
                  {i + 1}
                </div>
              ))}
            </div>

            {/* Interactive textarea editor */}
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => handleContentChange(e.target.value)}
              onKeyDown={handleKeyDown}
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
              className="flex-1 w-full p-3 font-mono text-xs text-[#dcdfe4] bg-transparent leading-6 resize-none focus:outline-none min-h-[380px] max-h-[550px] overflow-y-auto selection:bg-[#7b88ff]/40"
              placeholder="// วางหรือพิมพ์สคริปต์ build.gradle ที่นี่..."
            />
          </div>
        </div>
      )}

      {/* VIEW 2: Visual Dependency Manager */}
      {activeViewMode === 'dependencies' && (
        <div className="space-y-4">
          {/* Add Dependency Section */}
          <div className="bg-[#161622] p-4 rounded-2xl border border-[#2b2b3c] space-y-3">
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
              เพิ่ม Dependency กำหนดเอง (Custom Dependency)
            </span>
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <select
                value={customDepConfig}
                onChange={(e) => setCustomDepConfig(e.target.value)}
                className="w-full sm:w-44 bg-[#1b1b26] border border-[#333348] rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
              >
                <option value="implementation">implementation</option>
                <option value="api">api</option>
                <option value="kapt">kapt</option>
                <option value="compileOnly">compileOnly</option>
                <option value="testImplementation">testImplementation</option>
              </select>
              <input
                type="text"
                value={customDepInput}
                onChange={(e) => setCustomDepInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCustomDep()}
                placeholder="เช่น com.airbnb.android:lottie:6.4.0 หรือ androidx.camera:..."
                className="flex-1 w-full bg-[#1b1b26] border border-[#333348] rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#7b88ff]"
              />
              <button
                onClick={handleAddCustomDep}
                disabled={!customDepInput.trim()}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-[#7b88ff] hover:bg-[#6876ff] disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>เพิ่ม</span>
              </button>
            </div>
          </div>

          {/* Quick Add Presets */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
              เพิ่ม Library สำเร็จรูปยอดนิยม (1-Click Presets)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {PRESET_DEPENDENCIES.map((preset) => {
                const isAlreadyAdded = content.includes(preset.coordinate);
                return (
                  <div
                    key={preset.id}
                    className={`p-3 rounded-2xl border transition-all flex flex-col justify-between gap-2 ${
                      isAlreadyAdded
                        ? 'bg-emerald-500/5 border-emerald-500/30'
                        : 'bg-[#151520] border-[#292939] hover:border-[#3a3a52]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-bold text-white">{preset.name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#20202e] text-gray-400">
                          {preset.category}
                        </span>
                      </div>
                      <p className="text-[10px] text-gray-400 mt-1 line-clamp-2">
                        {preset.description}
                      </p>
                      <code className="text-[10px] font-mono text-[#9cb0ff] block mt-1.5 truncate">
                        {preset.coordinate}
                      </code>
                    </div>

                    <div className="pt-1 flex items-center justify-end">
                      {isAlreadyAdded ? (
                        <button
                          onClick={() => handleRemoveDep(preset.coordinate)}
                          className="px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 flex items-center gap-1 transition-all"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>นำออก</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleAddPresetDep(preset.coordinate)}
                          className="px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-[#7b88ff]/15 hover:bg-[#7b88ff]/25 text-[#9cb0ff] border border-[#7b88ff]/30 flex items-center gap-1 transition-all"
                        >
                          <Plus className="w-3 h-3" />
                          <span>เพิ่มเข้า Gradle</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Currently Detected / Parsed Dependencies list */}
          <div className="bg-[#14141e] p-4 rounded-2xl border border-[#2b2b3c] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#7b88ff]" />
                รายการ Dependencies ในสคริปต์ ({parsedInfo.dependencies.length})
              </span>
            </div>

            {parsedInfo.dependencies.length === 0 ? (
              <p className="text-xs text-gray-500 italic py-2">
                ไม่พบ dependencies ในสคริปต์ปัจจุบัน
              </p>
            ) : (
              <div className="divide-y divide-[#232332]">
                {parsedInfo.dependencies.map((dep, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#222232] text-indigo-300">
                          {dep.configuration}
                        </span>
                        <span className="font-mono text-gray-200 truncate">
                          {dep.coordinate}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemoveDep(dep.coordinate)}
                      className="p-1 rounded-lg text-gray-500 hover:text-rose-400 hover:bg-rose-500/10 transition-all shrink-0"
                      title="ลบ dependency นี้"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

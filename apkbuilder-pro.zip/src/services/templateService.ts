import JSZip from 'jszip';
import { ProjectSourceType } from '../types';

export interface SampleTemplate {
  id: string;
  name: string;
  type: ProjectSourceType;
  category: string;
  description: string;
  badge: string;
  icon: string;
  suggestedPackage: string;
  version: string;
}

export const SAMPLE_TEMPLATES: SampleTemplate[] = [
  // 1. Existing Pre-supported Templates
  {
    id: 'ai-studio-finance',
    name: 'Google AI Studio: Smart Finance',
    type: 'google_ai_studio',
    category: 'Google AI Studio',
    description: 'โปรเจกต์ React + Vite ส่งออกจาก Google AI Studio พร้อม metadata.json และ Local Storage',
    badge: 'Google AI Studio',
    icon: '📊',
    suggestedPackage: 'com.aistudio.financetracker',
    version: '1.0.0',
  },
  {
    id: 'native-kotlin-compose',
    name: 'Native Android: Jetpack Compose',
    type: 'native_gradle',
    category: 'Native Android',
    description: 'โปรเจกต์ Native Android (Gradle + Kotlin) พร้อม AndroidManifest.xml และ Gradle scripts',
    badge: 'Native Gradle',
    icon: '🤖',
    suggestedPackage: 'com.android.pro.tasks',
    version: '1.2.0',
  },

  // 2. Cross-Platform Framework Templates
  {
    id: 'flutter-counter',
    name: 'Flutter: Cross-Platform Portfolio',
    type: 'flutter',
    category: 'Cross-Platform Framework',
    description: 'โครงสร้างโปรเจกต์ Flutter (Dart) พร้อม pubspec.yaml, lib/main.dart และ Android bindings',
    badge: 'Flutter (Dart)',
    icon: '🦋',
    suggestedPackage: 'com.flutter.portfolio',
    version: '3.19.0',
  },
  {
    id: 'react-native-store',
    name: 'React Native: Mobile Commerce',
    type: 'react_native',
    category: 'Cross-Platform Framework',
    description: 'โครงสร้าง React Native & Metro พร้อม package.json (react-native), app.json และ App.tsx',
    badge: 'React Native',
    icon: '⚛️',
    suggestedPackage: 'com.rn.mobilecommerce',
    version: '0.74.0',
  },
  {
    id: 'dotnet-maui-pro',
    name: '.NET MAUI: Enterprise CRM',
    type: 'dotnet_maui',
    category: 'Cross-Platform Framework',
    description: 'โครงสร้าง .NET MAUI C# Mobile (.csproj พร้อม UseMaui=true และ MauiProgram.cs)',
    badge: '.NET MAUI (C#)',
    icon: '🟣',
    suggestedPackage: 'com.maui.enterprisecrm',
    version: '8.0.0',
  },

  // 3. Web Technologies (Web-based / Hybrid Apps)
  {
    id: 'capacitor-ionic-hybrid',
    name: 'Capacitor & Ionic: Modern Hybrid App',
    type: 'capacitor',
    category: 'Web-based / Hybrid',
    description: 'โครงสร้าง Hybrid App พร้อม capacitor.config.json, ionic.config.json และ www/ assets',
    badge: 'Capacitor Hybrid',
    icon: '⚡',
    suggestedPackage: 'com.capacitor.hybridapp',
    version: '5.6.0',
  },
  {
    id: 'cordova-classic',
    name: 'Apache Cordova: Hybrid Device Hub',
    type: 'cordova',
    category: 'Web-based / Hybrid',
    description: 'โครงสร้างคลาสสิก Cordova Hybrid พร้อม config.xml (<widget>), cordova.js และ www/',
    badge: 'Apache Cordova',
    icon: '📦',
    suggestedPackage: 'com.cordova.devicehub',
    version: '12.0.0',
  },
];

export async function createTemplateZip(templateId: string): Promise<File> {
  const zip = new JSZip();

  // Common SVG Icon for templates
  const makeIconSvg = (emoji: string, gradStart = '#7b88ff', gradEnd = '#38e08c') => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${gradStart}"/>
      <stop offset="100%" stop-color="${gradEnd}"/>
    </linearGradient>
  </defs>
  <rect width="100" height="100" rx="28" fill="url(#g)"/>
  <text x="50" y="66" font-size="46" text-anchor="middle">${emoji}</text>
</svg>`;

  if (templateId === 'flutter-counter') {
    // Flutter Project Structure
    zip.file('pubspec.yaml', `name: flutter_portfolio
description: A distinctive Flutter cross-platform mobile portfolio app.
version: 3.19.0+1
environment:
  sdk: '>=3.0.0 <4.0.0'
dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.6
flutter:
  uses-material-design: true
  assets:
    - assets/icon.png
`);
    zip.file('lib/main.dart', `import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Portfolio Pro',
      theme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(child: Text('Flutter Cross-Platform App Ready!')),
      ),
    );
  }
}
`);
    zip.file('android/app/build.gradle', `plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
}
android {
    namespace "com.flutter.portfolio"
    compileSdk 35
    defaultConfig {
        applicationId "com.flutter.portfolio"
        minSdk 24
        targetSdk 35
        versionCode 1
        versionName "3.19.0"
    }
}
`);
    zip.file('assets/icon.svg', makeIconSvg('🦋', '#02569B', '#0175C2'));
    zip.file('web/index.html', `<!DOCTYPE html><html><head><title>Flutter Web</title></head><body><h1>Flutter Loaded</h1></body></html>`);
    const blob = await zip.generateAsync({ type: 'blob' });
    return new File([blob], 'flutter-portfolio-project.zip', { type: 'application/zip' });
  }

  if (templateId === 'react-native-store') {
    // React Native Project Structure
    zip.file('package.json', JSON.stringify({
      name: 'react-native-commerce',
      version: '0.74.0',
      private: true,
      scripts: {
        android: 'react-native run-android',
        start: 'react-native start'
      },
      dependencies: {
        'react': '18.2.0',
        'react-native': '0.74.0',
        '@react-native-async-storage/async-storage': '^1.23.0'
      }
    }, null, 2));
    zip.file('app.json', JSON.stringify({
      name: 'ReactNativeCommerce',
      displayName: 'RN Mobile Commerce',
      expo: {
        name: 'RN Mobile Commerce',
        slug: 'rn-mobile-commerce',
        android: {
          package: 'com.rn.mobilecommerce'
        }
      }
    }, null, 2));
    zip.file('metro.config.js', `module.exports = { transformer: { getTransformOptions: async () => ({ transform: { experimentalImportSupport: false, inlineRequires: true } }) } };`);
    zip.file('index.js', `import {AppRegistry} from 'react-native';\nimport App from './App';\nAppRegistry.registerComponent('ReactNativeCommerce', () => App);`);
    zip.file('App.tsx', `import React from 'react';\nimport {View, Text} from 'react-native';\nexport default function App() { return <View><Text>React Native Running!</Text></View>; }`);
    zip.file('assets/icon.svg', makeIconSvg('⚛️', '#61dafb', '#1c2c4c'));
    const blob = await zip.generateAsync({ type: 'blob' });
    return new File([blob], 'react-native-commerce.zip', { type: 'application/zip' });
  }

  if (templateId === 'dotnet-maui-pro') {
    // .NET MAUI Project Structure
    zip.file('EnterpriseCRM.csproj', `<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFrameworks>net8.0-android</TargetFrameworks>
    <OutputType>Exe</OutputType>
    <RootNamespace>EnterpriseCRM</RootNamespace>
    <UseMaui>true</UseMaui>
    <SingleProject>true</SingleProject>
    <ApplicationTitle>Enterprise CRM Mobile</ApplicationTitle>
    <ApplicationId>com.maui.enterprisecrm</ApplicationId>
    <ApplicationDisplayVersion>8.0.0</ApplicationDisplayVersion>
    <ApplicationVersion>1</ApplicationVersion>
  </PropertyGroup>
</Project>`);
    zip.file('MauiProgram.cs', `namespace EnterpriseCRM;
public static class MauiProgram {
    public static MauiApp CreateMauiApp() {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        return builder.Build();
    }
}`);
    zip.file('Platforms/Android/AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.maui.enterprisecrm">
    <application android:label="Enterprise CRM Mobile" android:icon="@mipmap/appicon">
    </application>
</manifest>`);
    zip.file('Resources/AppIcon/appicon.svg', makeIconSvg('🟣', '#512BD4', '#A080FF'));
    const blob = await zip.generateAsync({ type: 'blob' });
    return new File([blob], 'dotnet-maui-crm.zip', { type: 'application/zip' });
  }

  if (templateId === 'capacitor-ionic-hybrid') {
    // Capacitor & Ionic Project Structure
    zip.file('capacitor.config.json', JSON.stringify({
      appId: 'com.capacitor.hybridapp',
      appName: 'Ionic Capacitor Store',
      webDir: 'dist',
      bundledWebRuntime: false
    }, null, 2));
    zip.file('ionic.config.json', JSON.stringify({
      name: 'Ionic Capacitor Store',
      integrations: {
        capacitor: {}
      },
      type: 'react'
    }, null, 2));
    zip.file('package.json', JSON.stringify({
      name: 'ionic-capacitor-store',
      version: '5.6.0',
      dependencies: {
        '@capacitor/core': '^5.6.0',
        '@capacitor/android': '^5.6.0',
        '@ionic/react': '^7.6.0',
        'react': '^18.2.0'
      }
    }, null, 2));
    zip.file('resources/icon.svg', makeIconSvg('⚡', '#3880ff', '#5260ff'));
    zip.file('dist/index.html', `<!doctype html><html><head><title>Ionic Capacitor App</title></head><body><h1>Ionic Capacitor Store Loaded!</h1></body></html>`);
    const blob = await zip.generateAsync({ type: 'blob' });
    return new File([blob], 'ionic-capacitor-store.zip', { type: 'application/zip' });
  }

  if (templateId === 'cordova-classic') {
    // Apache Cordova Project Structure
    zip.file('config.xml', `<?xml version='1.0' encoding='utf-8'?>
<widget id="com.cordova.devicehub" version="12.0.0" xmlns="http://www.w3.org/ns/widgets" xmlns:cdv="http://cordova.apache.org/ns/1.0">
    <name>Cordova Device Hub</name>
    <description>Apache Cordova Hybrid Mobile Application</description>
    <author email="dev@example.com">Cordova Engineer</author>
    <content src="index.html" />
    <access origin="*" />
</widget>`);
    zip.file('www/index.html', `<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Cordova Device Hub</title>
</head>
<body style="background:#111; color:#fff; font-family:sans-serif; text-align:center; padding:40px;">
    <h1>📦 Apache Cordova Running</h1>
    <p>Hybrid Device Hub bridge is active</p>
</body>
</html>`);
    zip.file('www/js/index.js', `document.addEventListener('deviceready', () => console.log('Cordova ready!'), false);`);
    zip.file('www/img/logo.svg', makeIconSvg('📦', '#E6CA65', '#D29C28'));
    const blob = await zip.generateAsync({ type: 'blob' });
    return new File([blob], 'cordova-devicehub.zip', { type: 'application/zip' });
  }

  if (templateId === 'native-kotlin-compose') {
    // Native Android Structure
    zip.file('build.gradle', `plugins {
    id 'com.android.application' version '8.2.2' apply false
    id 'org.jetbrains.kotlin.android' version '1.9.22' apply false
}`);
    zip.file('settings.gradle', `rootProject.name = "JetpackTasks"
include ':app'`);
    zip.file('app/build.gradle', `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}
android {
    namespace 'com.android.pro.tasks'
    compileSdk 35
    defaultConfig {
        applicationId "com.android.pro.tasks"
        minSdk 24
        targetSdk 35
        versionCode 1
        versionName "1.2.0"
    }
}`);
    zip.file('app/src/main/AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.android.pro.tasks">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:label="Jetpack Tasks"
        android:icon="@drawable/ic_launcher">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`);
    zip.file('app/src/main/java/com/android/pro/tasks/MainActivity.kt', `package com.android.pro.tasks
import android.os.Bundle
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}`);
    zip.file('app/src/main/res/drawable/ic_launcher.svg', makeIconSvg('🤖', '#3ddc84', '#073042'));
    const blob = await zip.generateAsync({ type: 'blob' });
    return new File([blob], 'native-android-tasks.zip', { type: 'application/zip' });
  }

  // Google AI Studio template
  zip.file('metadata.json', JSON.stringify({
    name: templateId === 'ai-studio-finance' ? 'AI Studio Finance Tracker' : 'AI Studio Smart Home',
    description: 'Exported from Google AI Studio',
    majorCapabilities: ['MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API'],
  }, null, 2));

  zip.file('package.json', JSON.stringify({
    name: templateId === 'ai-studio-finance' ? 'finance-tracker' : 'smart-home-iot',
    version: '1.0.0',
    type: 'module',
    scripts: { dev: 'vite', build: 'vite build' },
    dependencies: { react: '^19.0.0', 'react-dom': '^19.0.0', lucide: '^0.400.0' },
  }, null, 2));

  const iconSvg = makeIconSvg(templateId === 'ai-studio-finance' ? '📈' : '💡');
  zip.file('icon.svg', iconSvg);
  zip.file('public/icon.svg', iconSvg);

  zip.file('index.html', `<!doctype html>
<html lang="th">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href="/icon.svg" />
    <title>${templateId === 'ai-studio-finance' ? 'Finance Tracker Pro' : 'Smart Home Control'}</title>
</head>
<body style="margin:0; background:#0f0f13; color:#fff; font-family:sans-serif; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh;">
    <div style="background:#1e1e24; border-radius:24px; padding:32px; border:1px solid #333342; text-align:center; max-width:360px; margin:20px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
        <div style="font-size:48px; margin-bottom:12px;">${templateId === 'ai-studio-finance' ? '📈' : '💡'}</div>
        <h2 style="margin:0 0 8px 0; font-size:22px;">${templateId === 'ai-studio-finance' ? 'Smart Finance Tracker' : 'Smart Home IoT'}</h2>
        <p style="color:#aaa; font-size:14px; margin-bottom:24px;">สร้างจาก Google AI Studio แปลงเป็น APK สำเร็จและทำงานได้ลื่นไหล</p>
        <button style="background:#7b88ff; color:#0f0f13; border:none; padding:12px 24px; border-radius:999px; font-weight:bold; font-size:15px; cursor:pointer;" onclick="alert('แอปทำงานสมบูรณ์!')">
            ทดสอบการทำงาน
        </button>
    </div>
</body>
</html>`);

  zip.file('src/App.tsx', `export default function App() { return <div>App Loaded!</div>; }`);
  zip.file('src/main.tsx', `console.log("App initialized");`);

  const blob = await zip.generateAsync({ type: 'blob' });
  const filename = templateId === 'ai-studio-finance' ? 'google-ai-studio-finance.zip' : `${templateId}.zip`;
  return new File([blob], filename, { type: 'application/zip' });
}

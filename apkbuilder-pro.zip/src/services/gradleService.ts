import { AppConfig, ProjectAnalysis } from '../types';

export interface ParsedGradleInfo {
  compileSdk?: number;
  minSdk?: number;
  targetSdk?: number;
  applicationId?: string;
  namespace?: string;
  versionCode?: number;
  versionName?: string;
  dependencies: {
    raw: string;
    configuration: string; // implementation, api, etc.
    coordinate: string;
  }[];
  plugins: string[];
}

export interface PresetDependency {
  id: string;
  name: string;
  category: 'Core & UI' | 'Web & Hybrid' | 'Hardware & Media' | 'Network & Data' | 'Google Services';
  coordinate: string;
  description: string;
  configuration?: string;
}

export const PRESET_DEPENDENCIES: PresetDependency[] = [
  {
    id: 'webkit',
    name: 'AndroidX WebKit',
    category: 'Web & Hybrid',
    coordinate: 'androidx.webkit:webkit:1.11.0',
    description: 'API ขั้นสูงสำหรับ WebView, Chromium runtime, SafeBrowsing และ ServiceWorker',
  },
  {
    id: 'customtabs',
    name: 'Chrome Custom Tabs',
    category: 'Web & Hybrid',
    coordinate: 'androidx.browser:customtabs:1.8.0',
    description: 'เปิดหน้าเว็บภายนอกแบบ Seamless ประสิทธิภาพสูงพร้อมแชร์คุกกี้',
  },
  {
    id: 'core-ktx',
    name: 'Core KTX',
    category: 'Core & UI',
    coordinate: 'androidx.core:core-ktx:1.13.1',
    description: 'ส่วนขยาย Kotlin พื้นฐานสำหรับ Android Framework',
  },
  {
    id: 'material',
    name: 'Material Components 3',
    category: 'Core & UI',
    coordinate: 'com.google.android.material:material:1.12.0',
    description: 'ดีไซน์คอมโพเนนต์ Material You ล่าสุดจาก Google',
  },
  {
    id: 'appcompat',
    name: 'AndroidX AppCompat',
    category: 'Core & UI',
    coordinate: 'androidx.appcompat:appcompat:1.7.0',
    description: 'คอมโพเนนต์รองรับความเข้ากันได้ย้อนหลังทุกเวอร์ชันของ Android',
  },
  {
    id: 'lifecycle',
    name: 'Lifecycle & ViewModel KTX',
    category: 'Core & UI',
    coordinate: 'androidx.lifecycle:lifecycle-runtime-ktx:2.8.2',
    description: 'การจัดการรอบชีวิตแอพพลิเคชันและการทำงานแบบ Coroutines',
  },
  {
    id: 'coroutines',
    name: 'Kotlinx Coroutines Android',
    category: 'Network & Data',
    coordinate: 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1',
    description: 'การประมวลผลอะซิงโครนัสและเธรดเบื้องหลังใน Android',
  },
  {
    id: 'okhttp',
    name: 'OkHttp 4',
    category: 'Network & Data',
    coordinate: 'com.squareup.okhttp3:okhttp:4.12.0',
    description: 'HTTP client คุณภาพสูง รองรับ HTTP/2, WebSocket และการแคช',
  },
  {
    id: 'retrofit',
    name: 'Retrofit 2 REST Client',
    category: 'Network & Data',
    coordinate: 'com.squareup.retrofit2:retrofit:2.11.0',
    description: 'Type-safe HTTP client สำหรับติดต่อ Web APIs และ Microservices',
  },
  {
    id: 'gson',
    name: 'Google Gson',
    category: 'Network & Data',
    coordinate: 'com.google.code.gson:gson:2.10.1',
    description: 'ไลบรารีแปลง JSON เป็น Java/Kotlin Object และกลับกัน',
  },
  {
    id: 'camerax',
    name: 'CameraX Camera2',
    category: 'Hardware & Media',
    coordinate: 'androidx.camera:camera-camera2:1.3.4',
    description: 'ควบคุมกล้องถ่ายภาพความละเอียดสูง รองรับอุปกรณ์ Android ส่วนใหญ่',
  },
  {
    id: 'play-location',
    name: 'Google Play Location',
    category: 'Google Services',
    coordinate: 'com.google.android.gms:play-services-location:21.2.0',
    description: 'API ตำแหน่งและ GPS ความแม่นยำสูงจาก Google Play Services',
  },
];

export class GradleService {
  /**
   * Generate canonical build.gradle based on config and project structure
   */
  public static generateDefaultGradle(config: AppConfig, analysis?: ProjectAnalysis | null): string {
    const isFlutter = analysis?.detectedType === 'flutter';
    const isReactNative = analysis?.detectedType === 'react_native';
    const isIonicCapacitor = analysis?.detectedType === 'ionic' || analysis?.detectedType === 'capacitor';
    const isCordova = analysis?.detectedType === 'cordova';
    const isNative = analysis?.detectedType === 'native_gradle';

    const compileSdk = Math.max(config.targetSdkVersion || 34, 34);
    const minSdk = config.minSdkVersion || 24;
    const targetSdk = config.targetSdkVersion || 34;

    const extraPlugins = isFlutter
      ? `    id 'dev.flutter.flutter-gradle-plugin'\n`
      : isReactNative
      ? `    id 'com.facebook.react'\n`
      : '';

    let frameworkDependencies = '';
    if (isFlutter) {
      frameworkDependencies = `    // Flutter Android Embedding
    // Managed automatically by Flutter engine loader
`;
    } else if (isReactNative) {
      frameworkDependencies = `    // React Native Engine
    implementation 'com.facebook.react:react-android'
    implementation 'com.facebook.react:hermes-android'
`;
    } else if (isIonicCapacitor) {
      frameworkDependencies = `    // Capacitor / Ionic Android Runtime
    implementation 'androidx.webkit:webkit:1.11.0'
    implementation 'androidx.coordinatorlayout:coordinatorlayout:1.2.0'
`;
    } else if (isCordova) {
      frameworkDependencies = `    // Apache Cordova Android Bridge
    implementation 'androidx.webkit:webkit:1.11.0'
`;
    } else {
      frameworkDependencies = `    // AndroidX & Modern Web Hybrid Architecture
    implementation 'androidx.webkit:webkit:1.11.0'
`;
    }

    return `// ==============================================================================
// Android Application Build Script (app/build.gradle)
// Project: ${config.appName} (${analysis?.frameworkName || 'Android App'})
// Generated & Calibrated by APK Builder Pro Engine
// ==============================================================================

plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
${extraPlugins}}

android {
    namespace '${config.packageName}'
    compileSdk ${compileSdk}

    defaultConfig {
        applicationId "${config.packageName}"
        minSdk ${minSdk}
        targetSdk ${targetSdk}
        versionCode ${config.versionCode}
        versionName "${config.versionName}"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary true
        }

        ndk {
            abiFilters 'armeabi-v7a', 'arm64-v8a', 'x86_64'
        }
    }

    buildTypes {
        release {
            minifyEnabled false
            shrinkResources false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.debug
        }
        debug {
            applicationIdSuffix ""
            debuggable true
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }

    buildFeatures {
        viewBinding true
        buildConfig true
    }

    packaging {
        resources {
            excludes += '/META-INF/{AL2.0,LGPL2.1}'
        }
    }
}

dependencies {
    // AndroidX Core & UI Support
    implementation 'androidx.core:core-ktx:1.13.1'
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.8.2'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1'

${frameworkDependencies}
    // Unit Testing
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
`;
  }

  /**
   * Parse build.gradle content to extract SDK versions, applicationId, and dependencies
   */
  public static parseGradle(content: string): ParsedGradleInfo {
    const info: ParsedGradleInfo = {
      dependencies: [],
      plugins: [],
    };

    if (!content) return info;

    // 1. Compile SDK
    const compileSdkMatch = content.match(/compileSdk(?:Version)?\s*=?\s*(\d+)/);
    if (compileSdkMatch) {
      info.compileSdk = parseInt(compileSdkMatch[1], 10);
    }

    // 2. Min SDK
    const minSdkMatch = content.match(/minSdk(?:Version)?\s*=?\s*(\d+)/);
    if (minSdkMatch) {
      info.minSdk = parseInt(minSdkMatch[1], 10);
    }

    // 3. Target SDK
    const targetSdkMatch = content.match(/targetSdk(?:Version)?\s*=?\s*(\d+)/);
    if (targetSdkMatch) {
      info.targetSdk = parseInt(targetSdkMatch[1], 10);
    }

    // 4. Application ID / Namespace
    const appIdMatch = content.match(/applicationId\s*=?\s*["']([^"']+)["']/);
    if (appIdMatch) {
      info.applicationId = appIdMatch[1];
    }

    const namespaceMatch = content.match(/namespace\s*=?\s*["']([^"']+)["']/);
    if (namespaceMatch) {
      info.namespace = namespaceMatch[1];
    }

    // 5. Version Code
    const vcMatch = content.match(/versionCode\s*=?\s*(\d+)/);
    if (vcMatch) {
      info.versionCode = parseInt(vcMatch[1], 10);
    }

    // 6. Version Name
    const vnMatch = content.match(/versionName\s*=?\s*["']([^"']+)["']/);
    if (vnMatch) {
      info.versionName = vnMatch[1];
    }

    // 7. Dependencies parser
    // Looks for lines like: implementation 'group:artifact:version' or implementation("...")
    const depRegex = /^\s*(implementation|api|compileOnly|runtimeOnly|kapt|annotationProcessor|testImplementation|androidTestImplementation)\s*[\s(]['"]([^'"]+)['"]\)?/gm;
    let match: RegExpExecArray | null;
    while ((match = depRegex.exec(content)) !== null) {
      info.dependencies.push({
        raw: match[0].trim(),
        configuration: match[1],
        coordinate: match[2],
      });
    }

    // 8. Plugins
    const pluginRegex = /id\s*['"]([^'"]+)['"]/g;
    let pMatch: RegExpExecArray | null;
    while ((pMatch = pluginRegex.exec(content)) !== null) {
      info.plugins.push(pMatch[1]);
    }

    return info;
  }

  /**
   * Update or replace a property in the gradle content safely
   */
  public static updateProperty(
    content: string,
    property: 'minSdk' | 'targetSdk' | 'compileSdk' | 'applicationId' | 'versionCode' | 'versionName',
    newValue: string | number
  ): string {
    let result = content;

    switch (property) {
      case 'compileSdk':
        if (/compileSdk(?:Version)?\s*=?\s*\d+/.test(result)) {
          result = result.replace(/compileSdk(?:Version)?\s*=?\s*\d+/, `compileSdk ${newValue}`);
        } else if (/android\s*\{/.test(result)) {
          result = result.replace(/android\s*\{/, `android {\n    compileSdk ${newValue}`);
        }
        break;

      case 'minSdk':
        if (/minSdk(?:Version)?\s*=?\s*\d+/.test(result)) {
          result = result.replace(/minSdk(?:Version)?\s*=?\s*\d+/, `minSdk ${newValue}`);
        } else if (/defaultConfig\s*\{/.test(result)) {
          result = result.replace(/defaultConfig\s*\{/, `defaultConfig {\n        minSdk ${newValue}`);
        }
        break;

      case 'targetSdk':
        if (/targetSdk(?:Version)?\s*=?\s*\d+/.test(result)) {
          result = result.replace(/targetSdk(?:Version)?\s*=?\s*\d+/, `targetSdk ${newValue}`);
        } else if (/defaultConfig\s*\{/.test(result)) {
          result = result.replace(/defaultConfig\s*\{/, `defaultConfig {\n        targetSdk ${newValue}`);
        }
        break;

      case 'applicationId':
        if (/applicationId\s*=?\s*["'][^"']+["']/.test(result)) {
          result = result.replace(/applicationId\s*=?\s*["'][^"']+["']/, `applicationId "${newValue}"`);
        }
        if (/namespace\s*=?\s*["'][^"']+["']/.test(result)) {
          result = result.replace(/namespace\s*=?\s*["'][^"']+["']/, `namespace '${newValue}'`);
        }
        break;

      case 'versionCode':
        if (/versionCode\s*=?\s*\d+/.test(result)) {
          result = result.replace(/versionCode\s*=?\s*\d+/, `versionCode ${newValue}`);
        }
        break;

      case 'versionName':
        if (/versionName\s*=?\s*["'][^"']+["']/.test(result)) {
          result = result.replace(/versionName\s*=?\s*["'][^"']+["']/, `versionName "${newValue}"`);
        }
        break;
    }

    return result;
  }

  /**
   * Add a dependency coordinate to the dependencies { ... } block
   */
  public static addDependency(
    content: string,
    coordinate: string,
    configuration: string = 'implementation'
  ): string {
    const trimmed = coordinate.trim();
    if (content.includes(trimmed)) {
      return content; // already exists
    }

    const newLine = `    ${configuration} '${trimmed}'`;
    const depBlockRegex = /dependencies\s*\{([\s\S]*?)\}/;

    if (depBlockRegex.test(content)) {
      return content.replace(depBlockRegex, (match, inner) => {
        return `dependencies {\n${newLine}${inner.startsWith('\n') ? '' : '\n'}${inner}}`;
      });
    }

    // If no dependencies block found, append at bottom
    return `${content}\n\ndependencies {\n${newLine}\n}\n`;
  }

  /**
   * Remove a dependency from the gradle script
   */
  public static removeDependency(content: string, coordinate: string): string {
    const escaped = coordinate.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const lineRegex = new RegExp(`^.*['"]${escaped}['"].*$\\n?`, 'gm');
    return content.replace(lineRegex, '');
  }
}

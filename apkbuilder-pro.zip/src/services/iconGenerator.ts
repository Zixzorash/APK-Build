/**
 * Android Multi-Density PNG Icon Generator
 * Renders sharp, high-contrast, adaptive launcher icons across all standard Android DPIs
 * (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi) using custom icons extracted directly from the imported ZIP.
 */

export interface IconDensity {
  folder: string;
  size: number;
}

export const DENSITIES: IconDensity[] = [
  { folder: 'mipmap-mdpi', size: 48 },
  { folder: 'mipmap-hdpi', size: 72 },
  { folder: 'mipmap-xhdpi', size: 96 },
  { folder: 'mipmap-xxhdpi', size: 144 },
  { folder: 'mipmap-xxxhdpi', size: 192 },
];

export class IconGenerator {
  /**
   * Load any image blob (PNG, SVG, ICO, JPG, WEBP) into a CanvasImageSource
   */
  public static async createDrawableFromBlob(blob: Blob): Promise<CanvasImageSource> {
    const url = URL.createObjectURL(blob);
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => {
        createImageBitmap(blob)
          .then(resolve)
          .catch((err) => {
            console.warn('Failed to decode icon image bitmap:', err);
            reject(err);
          });
      };
      img.src = url;
    });
  }

  /**
   * Generates a PNG binary buffer for a given icon size using offscreen canvas
   */
  public static async generateLauncherIcon(
    size: number,
    appName: string,
    isRound = false,
    customDrawable?: CanvasImageSource
  ): Promise<Uint8Array> {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Cannot get 2d canvas context');

    ctx.clearRect(0, 0, size, size);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    if (customDrawable) {
      // Draw user provided custom icon extracted from imported ZIP
      ctx.save();
      ctx.beginPath();
      if (isRound) {
        ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
      } else {
        const radius = size * 0.22;
        this.roundRect(ctx, 0, 0, size, size, radius);
      }
      ctx.closePath();
      ctx.clip();

      // Draw custom icon centered and scaled
      ctx.drawImage(customDrawable, 0, 0, size, size);
      ctx.restore();
    } else {
      // Draw modern Material Design 3 adaptive squircle or round icon fallback
      const radius = isRound ? size / 2 : size * 0.24;

      // Base gradient squircle
      const gradient = ctx.createLinearGradient(0, 0, size, size);
      gradient.addColorStop(0, '#7b88ff');
      gradient.addColorStop(0.5, '#6c5ce7');
      gradient.addColorStop(1, '#00b894');

      ctx.save();
      ctx.beginPath();
      if (isRound) {
        ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
      } else {
        this.roundRect(ctx, size * 0.04, size * 0.04, size * 0.92, size * 0.92, radius);
      }
      ctx.fillStyle = gradient;
      ctx.fill();

      // Inner subtle dark glass plate
      ctx.beginPath();
      if (isRound) {
        ctx.arc(size / 2, size / 2, size * 0.44, 0, Math.PI * 2);
      } else {
        this.roundRect(ctx, size * 0.08, size * 0.08, size * 0.84, size * 0.84, radius * 0.85);
      }
      ctx.fillStyle = 'rgba(19, 19, 26, 0.88)';
      ctx.fill();

      // Android Robot Dome Head
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(size * 0.5, size * 0.44, size * 0.22, Math.PI, 0, false);
      ctx.fill();

      // Antennae
      ctx.strokeStyle = '#7b88ff';
      ctx.lineWidth = Math.max(2, size * 0.04);
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.moveTo(size * 0.38, size * 0.3);
      ctx.lineTo(size * 0.32, size * 0.2);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(size * 0.62, size * 0.3);
      ctx.lineTo(size * 0.68, size * 0.2);
      ctx.stroke();

      // Robot Eyes
      ctx.fillStyle = '#13131a';
      ctx.beginPath();
      ctx.arc(size * 0.42, size * 0.38, Math.max(1.5, size * 0.035), 0, Math.PI * 2);
      ctx.arc(size * 0.58, size * 0.38, Math.max(1.5, size * 0.035), 0, Math.PI * 2);
      ctx.fill();

      // Build Spark & Core Cube
      ctx.fillStyle = 'rgba(123, 136, 255, 0.18)';
      ctx.strokeStyle = '#7b88ff';
      ctx.lineWidth = Math.max(1.5, size * (1.8 / 64));
      const cubeX = size * (19 / 64);
      const cubeY = size * (31 / 64);
      const cubeW = size * (26 / 64);
      const cubeH = size * (21 / 64);
      const cubeR = size * (5 / 64);
      ctx.beginPath();
      this.roundRect(ctx, cubeX, cubeY, cubeW, cubeH, cubeR);
      ctx.fill();
      ctx.stroke();

      // Fast Lightning / Build Spark
      ctx.fillStyle = '#38e08c';
      ctx.beginPath();
      ctx.moveTo(size * (33 / 64), size * (33 / 64));
      ctx.lineTo(size * (26 / 64), size * (42 / 64));
      ctx.lineTo(size * (32 / 64), size * (42 / 64));
      ctx.lineTo(size * (30 / 64), size * (50 / 64));
      ctx.lineTo(size * (38 / 64), size * (41 / 64));
      ctx.lineTo(size * (32 / 64), size * (41 / 64));
      ctx.lineTo(size * (34 / 64), size * (33 / 64));
      ctx.closePath();
      ctx.fill();

      // Corner Pro badge dot
      ctx.fillStyle = '#38e08c';
      ctx.beginPath();
      ctx.arc(size * (51 / 64), size * (13 / 64), Math.max(2, size * (3.5 / 64)), 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }

    return await this.canvasToUint8Array(canvas);
  }

  /**
   * Return the raw SVG string of the official Header App Logo
   */
  public static getHeaderLogoSvg(): string {
    return `<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="m3GradPrimary" x1="4" y1="4" x2="60" y2="60" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#7b88ff" />
      <stop offset="50%" stop-color="#9373ee" />
      <stop offset="100%" stop-color="#38e08c" />
    </linearGradient>
    <linearGradient id="m3GradAccent" x1="16" y1="20" x2="48" y2="52" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.95" />
      <stop offset="100%" stop-color="#d1d5ff" stop-opacity="0.8" />
    </linearGradient>
  </defs>
  <rect x="3" y="3" width="58" height="58" rx="18" fill="url(#m3GradPrimary)" />
  <rect x="5" y="5" width="54" height="54" rx="16" fill="#13131a" fill-opacity="0.88" />
  <line x1="24" y1="20" x2="20" y2="14" stroke="#7b88ff" stroke-width="2.5" stroke-linecap="round" />
  <line x1="40" y1="20" x2="44" y2="14" stroke="#38e08c" stroke-width="2.5" stroke-linecap="round" />
  <path d="M20 28 C20 21.3726 25.3726 16 32 16 C38.6274 16 44 21.3726 44 28 Z" fill="url(#m3GradAccent)" />
  <circle cx="26" cy="23.5" r="1.8" fill="#13131a" />
  <circle cx="38" cy="23.5" r="1.8" fill="#13131a" />
  <rect x="19" y="31" width="26" height="21" rx="5" fill="#7b88ff" fill-opacity="0.18" stroke="#7b88ff" stroke-width="1.8" />
  <path d="M33 33 L26 42 H32 L30 50 L38 41 H32 L34 33 Z" fill="#38e08c" />
  <circle cx="51" cy="13" r="3.5" fill="#38e08c" />
</svg>`;
  }

  /**
   * Return a Blob of the official Header App Logo
   */
  public static getHeaderLogoBlob(): Blob {
    return new Blob([this.getHeaderLogoSvg()], { type: 'image/svg+xml' });
  }

  private static roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ) {
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
  }

  private static canvasToUint8Array(canvas: HTMLCanvasElement): Promise<Uint8Array> {
    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error('Canvas blob creation failed'));
          return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
          resolve(new Uint8Array(reader.result as ArrayBuffer));
        };
        reader.onerror = reject;
        reader.readAsArrayBuffer(blob);
      }, 'image/png');
    });
  }
}

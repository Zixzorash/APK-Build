package com.apkbuilder.pro.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.apkbuilder.pro.engine.AxmlCompiler
import com.apkbuilder.pro.engine.DexCompiler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class BuildUiState(
    val isBuilding: Boolean = false,
    val progressPercent: Int = 0,
    val currentPhase: String = "",
    val outputFormat: String = "apk",
    val appName: String = "My App Pro",
    val packageName: String = "com.aistudio.myapp",
    val versionName: String = "1.0.0",
    val versionCode: Int = 1,
    val targetSdk: Int = 35,
    val minSdk: Int = 24,
    val selectedZipUri: Uri? = null,
    val buildLogs: List<String> = emptyList(),
    val builtApkPath: String? = null,
    val errorMessage: String? = null
)

class ApkBuilderViewModel(application: Application) : AndroidViewModel(application) {
    private val _uiState = MutableStateFlow(BuildUiState())
    val uiState: StateFlow<BuildUiState> = _uiState.asStateFlow()

    fun updateConfig(
        appName: String? = null,
        packageName: String? = null,
        format: String? = null,
        version: String? = null
    ) {
        _uiState.value = _uiState.value.copy(
            appName = appName ?: _uiState.value.appName,
            packageName = packageName ?: _uiState.value.packageName,
            outputFormat = format ?: _uiState.value.outputFormat,
            versionName = version ?: _uiState.value.versionName
        )
    }

    fun selectZipFile(uri: Uri) {
        _uiState.value = _uiState.value.copy(selectedZipUri = uri)
    }

    fun startBuild() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = _uiState.value.copy(
                isBuilding = true,
                progressPercent = 10,
                currentPhase = "กำลังแยกวิเคราะห์ซอร์สโค้ด ZIP...",
                buildLogs = listOf("[Kotlin Engine] เริ่มกระบวนการแปลงไฟล์...")
            )

            try {
                // Phase 2: Binary AXML
                _uiState.value = _uiState.value.copy(
                    progressPercent = 40,
                    currentPhase = "คอมไพล์ Android Binary XML (AXML Format)..."
                )

                // Phase 3: Dalvik Executable
                _uiState.value = _uiState.value.copy(
                    progressPercent = 70,
                    currentPhase = "สังเคราะห์ไบต์โค้ด classes.dex สำหรับ ART..."
                )

                // Phase 4: Sign & Package
                _uiState.value = _uiState.value.copy(
                    progressPercent = 100,
                    isBuilding = false,
                    currentPhase = "เสร็จสิ้นการสร้าง APK!",
                    builtApkPath = "build/outputs/apk/release/app-release.apk"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isBuilding = false,
                    errorMessage = e.localizedMessage
                )
            }
        }
    }
}
